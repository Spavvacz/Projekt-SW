/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define START_Pin GPIO_PIN_0
#define START_GPIO_Port GPIOA
#define STOP_Pin GPIO_PIN_1
#define STOP_GPIO_Port GPIOA
#define dziesiec_sek_Pin GPIO_PIN_4
#define dziesiec_sek_GPIO_Port GPIOA
#define minuta_Pin GPIO_PIN_5
#define minuta_GPIO_Port GPIOA
#define dziesiec_minut_Pin GPIO_PIN_6
#define dziesiec_minut_GPIO_Port GPIOA
#define magnetron_Pin GPIO_PIN_4
#define magnetron_GPIO_Port GPIOC
#define MOCplus_Pin GPIO_PIN_1
#define MOCplus_GPIO_Port GPIOB
#define MOCminus_Pin GPIO_PIN_2
#define MOCminus_GPIO_Port GPIOB
#define A1_Pin GPIO_PIN_12
#define A1_GPIO_Port GPIOE
#define A2_Pin GPIO_PIN_13
#define A2_GPIO_Port GPIOE
#define A3_Pin GPIO_PIN_14
#define A3_GPIO_Port GPIOE
#define A4_Pin GPIO_PIN_15
#define A4_GPIO_Port GPIOE
#define segment_A_Pin GPIO_PIN_9
#define segment_A_GPIO_Port GPIOD
#define segment_B_Pin GPIO_PIN_10
#define segment_B_GPIO_Port GPIOD
#define segment_C_Pin GPIO_PIN_11
#define segment_C_GPIO_Port GPIOD
#define segment_D_Pin GPIO_PIN_12
#define segment_D_GPIO_Port GPIOD
#define segment_E_Pin GPIO_PIN_13
#define segment_E_GPIO_Port GPIOD
#define segment_F_Pin GPIO_PIN_14
#define segment_F_GPIO_Port GPIOD
#define segment_G_Pin GPIO_PIN_15
#define segment_G_GPIO_Port GPIOD
/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
