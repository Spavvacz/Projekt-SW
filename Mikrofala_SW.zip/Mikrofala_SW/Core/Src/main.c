/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2022 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;

osThreadId defaultTaskHandle;
osThreadId myTask02Handle;
osThreadId myTask03Handle;
osThreadId myTask05Handle;
osMessageQId sekundyQueueHandle;
osMessageQId minutyQueueHandle;
osMessageQId trybQueueHandle;
osMessageQId pwmQueueHandle;
osTimerId timer1Handle;
osTimerId timer2Handle;
osTimerId timer3Handle;
osTimerId timer4Handle;
osTimerId timer5Handle;
osTimerId pwmHandle;
osTimerId timer_sekundaHandle;
osTimerId timer6Handle;
osTimerId timer7Handle;
osSemaphoreId timer1SemaphoreHandle;
osSemaphoreId timer2SemaphoreHandle;
osSemaphoreId timer3SemaphoreHandle;
osSemaphoreId timer4SemaphoreHandle;
osSemaphoreId timer5SemaphoreHandle;
osSemaphoreId START_SemaphoreHandle;
osSemaphoreId STOP_SemaphoreHandle;
osSemaphoreId dziesiec_sek_SemaphoreHandle;
osSemaphoreId minuta_SemaphoreHandle;
osSemaphoreId dziesiec_minut_SemaphoreHandle;
osSemaphoreId tim_sekunda_SemaphoreHandle;
osSemaphoreId MOCplus_SemaphoreHandle;
osSemaphoreId MOCminus_SemaphoreHandle;
osSemaphoreId timer6_SemaphoreHandle;
osSemaphoreId timer7_SemaphoreHandle;
osSemaphoreId timer_sekunda_SemaphoreHandle;
osSemaphoreId pwm_SemaphoreHandle;
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
void StartDefaultTask(void const * argument);
void wyswietlanie(void const * argument);
void obsluga_przyciskow(void const * argument);
void odliczanie(void const * argument);
void Callback_timer1(void const * argument);
void Callback_timer2(void const * argument);
void Callback_timer3(void const * argument);
void Callback_timer4(void const * argument);
void Callback_timer5(void const * argument);
void Callback_pwm(void const * argument);
void Callback_sekunda(void const * argument);
void Callback_timer6(void const * argument);
void Callback_timer7(void const * argument);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* USER CODE BEGIN RTOS_MUTEX */
	/* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* Create the semaphores(s) */
  /* definition and creation of timer1Semaphore */
  osSemaphoreDef(timer1Semaphore);
  timer1SemaphoreHandle = osSemaphoreCreate(osSemaphore(timer1Semaphore), 1);

  /* definition and creation of timer2Semaphore */
  osSemaphoreDef(timer2Semaphore);
  timer2SemaphoreHandle = osSemaphoreCreate(osSemaphore(timer2Semaphore), 1);

  /* definition and creation of timer3Semaphore */
  osSemaphoreDef(timer3Semaphore);
  timer3SemaphoreHandle = osSemaphoreCreate(osSemaphore(timer3Semaphore), 1);

  /* definition and creation of timer4Semaphore */
  osSemaphoreDef(timer4Semaphore);
  timer4SemaphoreHandle = osSemaphoreCreate(osSemaphore(timer4Semaphore), 1);

  /* definition and creation of timer5Semaphore */
  osSemaphoreDef(timer5Semaphore);
  timer5SemaphoreHandle = osSemaphoreCreate(osSemaphore(timer5Semaphore), 1);

  /* definition and creation of START_Semaphore */
  osSemaphoreDef(START_Semaphore);
  START_SemaphoreHandle = osSemaphoreCreate(osSemaphore(START_Semaphore), 1);

  /* definition and creation of STOP_Semaphore */
  osSemaphoreDef(STOP_Semaphore);
  STOP_SemaphoreHandle = osSemaphoreCreate(osSemaphore(STOP_Semaphore), 1);

  /* definition and creation of dziesiec_sek_Semaphore */
  osSemaphoreDef(dziesiec_sek_Semaphore);
  dziesiec_sek_SemaphoreHandle = osSemaphoreCreate(osSemaphore(dziesiec_sek_Semaphore), 1);

  /* definition and creation of minuta_Semaphore */
  osSemaphoreDef(minuta_Semaphore);
  minuta_SemaphoreHandle = osSemaphoreCreate(osSemaphore(minuta_Semaphore), 1);

  /* definition and creation of dziesiec_minut_Semaphore */
  osSemaphoreDef(dziesiec_minut_Semaphore);
  dziesiec_minut_SemaphoreHandle = osSemaphoreCreate(osSemaphore(dziesiec_minut_Semaphore), 1);

  /* definition and creation of tim_sekunda_Semaphore */
  osSemaphoreDef(tim_sekunda_Semaphore);
  tim_sekunda_SemaphoreHandle = osSemaphoreCreate(osSemaphore(tim_sekunda_Semaphore), 1);

  /* definition and creation of MOCplus_Semaphore */
  osSemaphoreDef(MOCplus_Semaphore);
  MOCplus_SemaphoreHandle = osSemaphoreCreate(osSemaphore(MOCplus_Semaphore), 1);

  /* definition and creation of MOCminus_Semaphore */
  osSemaphoreDef(MOCminus_Semaphore);
  MOCminus_SemaphoreHandle = osSemaphoreCreate(osSemaphore(MOCminus_Semaphore), 1);

  /* definition and creation of timer6_Semaphore */
  osSemaphoreDef(timer6_Semaphore);
  timer6_SemaphoreHandle = osSemaphoreCreate(osSemaphore(timer6_Semaphore), 1);

  /* definition and creation of timer7_Semaphore */
  osSemaphoreDef(timer7_Semaphore);
  timer7_SemaphoreHandle = osSemaphoreCreate(osSemaphore(timer7_Semaphore), 1);

  /* definition and creation of timer_sekunda_Semaphore */
  osSemaphoreDef(timer_sekunda_Semaphore);
  timer_sekunda_SemaphoreHandle = osSemaphoreCreate(osSemaphore(timer_sekunda_Semaphore), 1);

  /* definition and creation of pwm_Semaphore */
  osSemaphoreDef(pwm_Semaphore);
  pwm_SemaphoreHandle = osSemaphoreCreate(osSemaphore(pwm_Semaphore), 1);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
	/* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* Create the timer(s) */
  /* definition and creation of timer1 */
  osTimerDef(timer1, Callback_timer1);
  timer1Handle = osTimerCreate(osTimer(timer1), osTimerPeriodic, NULL);

  /* definition and creation of timer2 */
  osTimerDef(timer2, Callback_timer2);
  timer2Handle = osTimerCreate(osTimer(timer2), osTimerPeriodic, NULL);

  /* definition and creation of timer3 */
  osTimerDef(timer3, Callback_timer3);
  timer3Handle = osTimerCreate(osTimer(timer3), osTimerPeriodic, NULL);

  /* definition and creation of timer4 */
  osTimerDef(timer4, Callback_timer4);
  timer4Handle = osTimerCreate(osTimer(timer4), osTimerPeriodic, NULL);

  /* definition and creation of timer5 */
  osTimerDef(timer5, Callback_timer5);
  timer5Handle = osTimerCreate(osTimer(timer5), osTimerPeriodic, NULL);

  /* definition and creation of pwm */
  osTimerDef(pwm, Callback_pwm);
  pwmHandle = osTimerCreate(osTimer(pwm), osTimerPeriodic, NULL);

  /* definition and creation of timer_sekunda */
  osTimerDef(timer_sekunda, Callback_sekunda);
  timer_sekundaHandle = osTimerCreate(osTimer(timer_sekunda), osTimerPeriodic, NULL);

  /* definition and creation of timer6 */
  osTimerDef(timer6, Callback_timer6);
  timer6Handle = osTimerCreate(osTimer(timer6), osTimerPeriodic, NULL);

  /* definition and creation of timer7 */
  osTimerDef(timer7, Callback_timer7);
  timer7Handle = osTimerCreate(osTimer(timer7), osTimerPeriodic, NULL);

  /* USER CODE BEGIN RTOS_TIMERS */
	/* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* definition and creation of sekundyQueue */
  osMessageQDef(sekundyQueue, 16, uint8_t);
  sekundyQueueHandle = osMessageCreate(osMessageQ(sekundyQueue), NULL);

  /* definition and creation of minutyQueue */
  osMessageQDef(minutyQueue, 16, uint8_t);
  minutyQueueHandle = osMessageCreate(osMessageQ(minutyQueue), NULL);

  /* definition and creation of trybQueue */
  osMessageQDef(trybQueue, 16, uint16_t);
  trybQueueHandle = osMessageCreate(osMessageQ(trybQueue), NULL);

  /* definition and creation of pwmQueue */
  osMessageQDef(pwmQueue, 16, uint16_t);
  pwmQueueHandle = osMessageCreate(osMessageQ(pwmQueue), NULL);

  /* USER CODE BEGIN RTOS_QUEUES */
	/* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of defaultTask */
  osThreadDef(defaultTask, StartDefaultTask, osPriorityIdle, 0, 128);
  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);

  /* definition and creation of myTask02 */
  osThreadDef(myTask02, wyswietlanie, osPriorityNormal, 0, 128);
  myTask02Handle = osThreadCreate(osThread(myTask02), NULL);

  /* definition and creation of myTask03 */
  osThreadDef(myTask03, obsluga_przyciskow, osPriorityNormal, 0, 128);
  myTask03Handle = osThreadCreate(osThread(myTask03), NULL);

  /* definition and creation of myTask05 */
  osThreadDef(myTask05, odliczanie, osPriorityIdle, 0, 128);
  myTask05Handle = osThreadCreate(osThread(myTask05), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
	/* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	while (1)
	{
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 100;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 8;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 4294967295;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 0;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(magnetron_GPIO_Port, magnetron_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, A1_Pin|A2_Pin|A3_Pin|A4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, segment_A_Pin|segment_B_Pin|segment_C_Pin|segment_D_Pin
                          |segment_E_Pin|segment_F_Pin|segment_G_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : START_Pin STOP_Pin dziesiec_sek_Pin minuta_Pin
                           dziesiec_minut_Pin */
  GPIO_InitStruct.Pin = START_Pin|STOP_Pin|dziesiec_sek_Pin|minuta_Pin
                          |dziesiec_minut_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : magnetron_Pin */
  GPIO_InitStruct.Pin = magnetron_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(magnetron_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : MOCplus_Pin MOCminus_Pin */
  GPIO_InitStruct.Pin = MOCplus_Pin|MOCminus_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : A1_Pin A2_Pin A3_Pin A4_Pin */
  GPIO_InitStruct.Pin = A1_Pin|A2_Pin|A3_Pin|A4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : segment_A_Pin segment_B_Pin segment_C_Pin segment_D_Pin
                           segment_E_Pin segment_F_Pin */
  GPIO_InitStruct.Pin = segment_A_Pin|segment_B_Pin|segment_C_Pin|segment_D_Pin
                          |segment_E_Pin|segment_F_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pin : segment_G_Pin */
  GPIO_InitStruct.Pin = segment_G_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(segment_G_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartDefaultTask */
/**
 * @brief  Function implementing the defaultTask thread.
 * @param  argument: Not used
 * @retval None
 */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void const * argument)
{
  /* USER CODE BEGIN 5 */
	/* Infinite loop */
	for(;;)
	{
		osDelay(1);
	}
  /* USER CODE END 5 */
}

/* USER CODE BEGIN Header_wyswietlanie */
/**
 * @brief Function implementing the myTask02 thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_wyswietlanie */
void wyswietlanie(void const * argument)
{
  /* USER CODE BEGIN wyswietlanie */
	uint8_t cyfry[10]= {0b1000000, 0b1111001, 0b0100100, 0b0110000, 0b0011001, 0b0010010, 0b0000010, 0b1111000, 0b0000000, 0b0010000};
	uint8_t minuty=0;
	uint8_t sekundy=0;
	int8_t min_kolejka = 0;
	uint8_t sek_kolejka = 0;
	uint8_t cyfra1 = 0;
	uint8_t cyfra2 = 0;
	uint8_t cyfra3 = 0;
	uint8_t cyfra4 = 0;
	uint8_t cyfra1temp = 0;
	uint8_t cyfra2temp = 0;
	uint8_t cyfra3temp = 0;
	uint8_t cyfra4temp = 0;
	uint8_t pwm = 0;
	uint8_t licznik_pwm = 0;
	uint8_t tryb = 0;
	xTimerStart(pwmHandle, 0);
	xTimerChangePeriod(pwmHandle,100 ,0);

	/* Infinite loop */
	for(;;)
	{
  		if(xSemaphoreTake(pwm_SemaphoreHandle, 1) == pdTRUE)
  		{
  			licznik_pwm++;
  		}
  		if(licznik_pwm > 100)
  		{
  			licznik_pwm = 0;
  		}

  		if(licznik_pwm <= pwm)
  		{
  			HAL_GPIO_WritePin(magnetron_GPIO_Port, magnetron_Pin, GPIO_PIN_RESET);
  		}
  		if(licznik_pwm >= pwm)
  		{
  			HAL_GPIO_WritePin(magnetron_GPIO_Port, magnetron_Pin, GPIO_PIN_SET);
  		}
		if(tryb == 1 && xQueueReceive(pwmQueueHandle, &pwm, 0)==pdTRUE)//stop wyswietlanie wypelnienia PWM
		{
			cyfra3 = pwm / 10;
			cyfra3temp = cyfry[cyfra1];
			cyfra4 = pwm % 10;
			cyfra4temp = cyfry[cyfra2];

			GPIOD->ODR = cyfra3temp;
			HAL_GPIO_WritePin(A3_GPIO_Port, A3_Pin, GPIO_PIN_SET);
			vTaskDelay(5);
			HAL_GPIO_WritePin(A3_GPIO_Port, A3_Pin, GPIO_PIN_RESET);

			GPIOD->ODR = cyfra4temp;
			HAL_GPIO_WritePin(A4_GPIO_Port, A4_Pin, GPIO_PIN_SET);
			vTaskDelay(5);
			HAL_GPIO_WritePin(A4_GPIO_Port, A4_Pin, GPIO_PIN_RESET);
		}


		else if(tryb == 0)//odliczanie
		{
			if(xQueueReceive(sekundyQueueHandle, &sekundy,0)==pdTRUE && xQueueReceive(minutyQueueHandle, &minuty,0)==pdTRUE)
			{
			minuty = min_kolejka/60;
			sekundy = sek_kolejka%60;
			cyfra1 = minuty / 10;
			cyfra1temp = cyfry[cyfra1];
			cyfra2 = minuty % 10;
			cyfra2temp = cyfry[cyfra2];
			cyfra3 = sekundy / 10;
			cyfra2temp = cyfry[cyfra3];
			cyfra4 = sekundy % 10;
			cyfra4temp = cyfry[cyfra4];

			GPIOD->ODR = cyfra1temp;
			HAL_GPIO_WritePin(A1_GPIO_Port, A1_Pin, GPIO_PIN_SET);
			vTaskDelay(5);
			HAL_GPIO_WritePin(A1_GPIO_Port, A1_Pin, GPIO_PIN_RESET);

			GPIOD->ODR = cyfra2temp;
			HAL_GPIO_WritePin(A2_GPIO_Port, A2_Pin, GPIO_PIN_SET);
			vTaskDelay(5);
			HAL_GPIO_WritePin(A2_GPIO_Port, A2_Pin, GPIO_PIN_RESET);

			GPIOD->ODR = cyfra3temp;
			HAL_GPIO_WritePin(A3_GPIO_Port, A3_Pin, GPIO_PIN_SET);
			vTaskDelay(5);
			HAL_GPIO_WritePin(A3_GPIO_Port, A3_Pin, GPIO_PIN_RESET);

			GPIOD->ODR = cyfra4temp;
			HAL_GPIO_WritePin(A4_GPIO_Port, A4_Pin, GPIO_PIN_SET);
			vTaskDelay(5);
			HAL_GPIO_WritePin(A4_GPIO_Port, A4_Pin, GPIO_PIN_RESET);
			}
		}
	}
  /* USER CODE END wyswietlanie */
}

/* USER CODE BEGIN Header_obsluga_przyciskow */
/**
 * @brief Function implementing the myTask03 thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_obsluga_przyciskow */
void obsluga_przyciskow(void const * argument)
{
  /* USER CODE BEGIN obsluga_przyciskow */
	uint8_t START1_temp=0; //BUTTON
	uint8_t START2_temp=0; //LAST
	uint8_t STOP1_temp=0;
	uint8_t STOP2_temp=0;
	uint8_t dziesiec_sek1_temp=0;
	uint8_t dziesiec_sek2_temp=0;
	uint8_t minuta1_temp;
	uint8_t minuta2_temp;
	uint8_t dziesiec_minut1_temp;
	uint8_t dziesiec_minut2_temp;
	uint8_t MOCP1_temp = 0;
	uint8_t MOCP2_temp= 0;
	uint8_t MOCM1_temp= 0;
	uint8_t MOCM2_temp= 0;
	uint8_t tryb = 0;
	/* Infinite loop */
	for(;;)
	{

		/* &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& PRZYCISK START &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& */
		if (HAL_GPIO_ReadPin(START_GPIO_Port, START_Pin) == 1) {
			START1_temp = 1;
			xTimerStart(timer1Handle, 0);
			xTimerChangePeriod(timer2Handle,50 ,0);
			if (HAL_GPIO_ReadPin(START_GPIO_Port, START_Pin) == 1 && START1_temp == 1 &&
					(xSemaphoreTake( timer1SemaphoreHandle, portMAX_DELAY) == pdTRUE) && !START2_temp)
			{
				START2_temp = 1;
				tryb = 1;
				xSemaphoreGive(START_SemaphoreHandle);

			}
		}
		if (HAL_GPIO_ReadPin(START_GPIO_Port, START_Pin) == 0)
		{
			START2_temp = 0;
			START1_temp= 0;
		}
		/* &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& PRZYCISK STOP &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& */
		if (HAL_GPIO_ReadPin(STOP_GPIO_Port, STOP_Pin) == 1) {
			STOP1_temp = 1;
			xTimerStart(timer1Handle, 0);
			xTimerChangePeriod(timer1Handle,50 ,0);
			if (HAL_GPIO_ReadPin(STOP_GPIO_Port, STOP_Pin) == 1 && STOP1_temp == 1 &&
					(xSemaphoreTake( timer2SemaphoreHandle, portMAX_DELAY) == pdTRUE) && !STOP2_temp)
			{
				STOP2_temp = 1;
				xSemaphoreGive(STOP_SemaphoreHandle);
				tryb = 0;
			}
		}
		if (HAL_GPIO_ReadPin(STOP_GPIO_Port, STOP_Pin) == 0)
		{
			STOP1_temp = 0;
			STOP2_temp= 0;
		}
		/* &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& PRZYCISK dziesiec_sek &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& */
		if (HAL_GPIO_ReadPin(dziesiec_sek_GPIO_Port, dziesiec_sek_Pin) == 1) {
			dziesiec_sek1_temp = 1;
			xTimerStart(timer2Handle, 0);
			xTimerChangePeriod(timer2Handle,50 ,0);
			if (HAL_GPIO_ReadPin(dziesiec_sek_GPIO_Port, dziesiec_sek_Pin) == 1 && dziesiec_sek1_temp == 1 &&
					(xSemaphoreTake( timer3SemaphoreHandle, portMAX_DELAY) == pdTRUE) && !dziesiec_sek2_temp)
			{
				dziesiec_sek1_temp = 1;
				xSemaphoreGive(dziesiec_sek_SemaphoreHandle);
			}
		}
		if (HAL_GPIO_ReadPin(dziesiec_sek_GPIO_Port, dziesiec_sek_Pin) == 0)
		{
			dziesiec_sek1_temp = 0;
			dziesiec_sek2_temp = 0;
		}

		/* &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& PRZYCISK minuta1_temp &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& */
		if (HAL_GPIO_ReadPin(minuta_GPIO_Port, minuta_Pin) == 1) {
			minuta1_temp = 1;
			xTimerStart(timer3Handle, 0);
			xTimerChangePeriod(timer3Handle,50 ,0);
			if (HAL_GPIO_ReadPin(minuta_GPIO_Port, minuta_Pin) == 1 && minuta1_temp == 1 &&
					(xSemaphoreTake( timer4SemaphoreHandle, portMAX_DELAY) == pdTRUE) && !minuta2_temp)
			{
				minuta1_temp = 1;
				xSemaphoreGive(minuta_SemaphoreHandle);
			}
		}
		if (HAL_GPIO_ReadPin(minuta_GPIO_Port, minuta_Pin) == 0)
		{
			minuta1_temp =0;
			minuta2_temp = 0;
		}

		/* &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& PRZYCISK dziesiec_minut1 &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& */
		if (HAL_GPIO_ReadPin(dziesiec_minut_GPIO_Port, dziesiec_minut_Pin) == 1) {
			dziesiec_minut1_temp = 1;
			xTimerStart(timer4Handle, 0);
			xTimerChangePeriod(timer4Handle,50 ,0);
			if (HAL_GPIO_ReadPin(dziesiec_minut_GPIO_Port, dziesiec_minut_Pin) == 1 && dziesiec_minut1_temp == 1 &&
					(xSemaphoreTake( timer5SemaphoreHandle, portMAX_DELAY) == pdTRUE) && !dziesiec_minut2_temp)
			{
				dziesiec_minut1_temp = 1;
				xSemaphoreGive(dziesiec_minut_SemaphoreHandle);
			}
		}
		if (HAL_GPIO_ReadPin(dziesiec_minut_GPIO_Port, dziesiec_minut_Pin) == 0)
		{
			dziesiec_minut1_temp = 0;
			dziesiec_minut2_temp= 0;
		}
		/* &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& PRZYCISK MOC+ &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& */
		if (HAL_GPIO_ReadPin(MOCplus_GPIO_Port, MOCplus_Pin) == 1) {
			MOCP1_temp= 1;
			xTimerStart(timer6Handle, 0);
			xTimerChangePeriod(timer6Handle,50 ,0);
			if (HAL_GPIO_ReadPin(MOCplus_GPIO_Port, MOCplus_Pin) == 1 && MOCP1_temp == 1 &&
					(xSemaphoreTake( timer6_SemaphoreHandle, portMAX_DELAY) == pdTRUE) && !MOCP2_temp)
			{
				MOCP1_temp = 1;
				xSemaphoreGive(MOCplus_SemaphoreHandle);
			}
		}
		if (HAL_GPIO_ReadPin(MOCplus_GPIO_Port, MOCplus_Pin) == 0)
		{
			MOCP1_temp = 0;
			MOCP2_temp= 0;

		}
		/* &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& PRZYCISK MOC- &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& */
		if (HAL_GPIO_ReadPin(MOCminus_GPIO_Port, MOCminus_Pin) == 1) {
			MOCM1_temp = 1;
			xTimerStart(timer7Handle, 0);
			xTimerChangePeriod(timer7Handle,50 ,0);
			if (HAL_GPIO_ReadPin(MOCminus_GPIO_Port, MOCminus_Pin) == 1 && MOCM1_temp == 1 &&
					(xSemaphoreTake(timer7_SemaphoreHandle, portMAX_DELAY) == pdTRUE) && !MOCM2_temp)
			{
				MOCM1_temp = 1;
				xSemaphoreGive(MOCminus_SemaphoreHandle);
			}
		}
		if (HAL_GPIO_ReadPin(MOCminus_GPIO_Port, MOCminus_Pin) == 0)
		{
			MOCM1_temp = 0;
			MOCM2_temp= 0;
		}
			xQueueSend(trybQueueHandle, &tryb, 0);
	}
  /* USER CODE END obsluga_przyciskow */
}

/* USER CODE BEGIN Header_odliczanie */
/**
 * @brief Function implementing the myTask05 thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_odliczanie */
void odliczanie(void const * argument)
{
  /* USER CODE BEGIN odliczanie */
	uint8_t minuty = 0;//zmienna minut
	uint8_t sekundy = 0;
	uint8_t moc = 0;
	uint8_t tryb = 0;
	xTimerStart(timer_sekundaHandle,0);
	xTimerChangePeriod(timer_sekundaHandle,1000,0);
	/* Infinite loop */
	for(;;)
	{
		if(xQueueReceive(trybQueueHandle, &tryb,0)== pdTRUE)
		{
		//ustawianie wartosci wciskajac przyciski oraz bedac w trybie liczenia
		if(xSemaphoreTake(dziesiec_sek_SemaphoreHandle, 1) == pdTRUE && tryb == 0)
		{
			sekundy = sekundy + 10;
		}
		if(xSemaphoreTake(minuta_SemaphoreHandle, 1) == pdTRUE && tryb == 0)
		{
			minuty++;
		}
		if(xSemaphoreTake(dziesiec_minut_SemaphoreHandle, 1) == pdTRUE && tryb == 0)
		{
			minuty = minuty + 10;
		}
		if(xSemaphoreTake(MOCplus_SemaphoreHandle, 1) == pdTRUE && tryb == 1)
		{
			moc = moc + 10;
			if(moc>100) moc = 100;

		}
		if(xSemaphoreTake(MOCminus_SemaphoreHandle, 1) == pdTRUE && tryb == 1)
		{
			moc = moc - 10;
			if(moc<10) moc = 10;
		}
		if(xSemaphoreTake(STOP_SemaphoreHandle,1) == pdTRUE && tryb == 0) //zerowanie minut i sekund przy wcisnieciu stop bedac w stop
		{
			sekundy=0;
			minuty=0;
		}
		if(xSemaphoreTake(timer_sekunda_SemaphoreHandle, 1) == pdTRUE && tryb == 0 && minuty > 0 && sekundy > 0) //odliczanie bedac w trybie start i przy niezerowych wartosciach
		{
			if (sekundy>0)
			{
				sekundy--;
			}
			else if(sekundy==0 && minuty>0)
			{
				sekundy=59;
				minuty--;
			}
			xQueueSend(sekundyQueueHandle, &sekundy, 0);
			xQueueSend(minutyQueueHandle, &minuty, 0);
			xQueueSend(pwmQueueHandle, &moc, 0);
		}
		}
	}
  /* USER CODE END odliczanie */
}

/* Callback_timer1 function */
void Callback_timer1(void const * argument)
{
  /* USER CODE BEGIN Callback_timer1 */
	xSemaphoreGiveFromISR(timer1SemaphoreHandle,0);
  /* USER CODE END Callback_timer1 */
}

/* Callback_timer2 function */
void Callback_timer2(void const * argument)
{
  /* USER CODE BEGIN Callback_timer2 */
	xSemaphoreGiveFromISR(timer2SemaphoreHandle,0);
  /* USER CODE END Callback_timer2 */
}

/* Callback_timer3 function */
void Callback_timer3(void const * argument)
{
  /* USER CODE BEGIN Callback_timer3 */
	xSemaphoreGiveFromISR(timer3SemaphoreHandle,0);
  /* USER CODE END Callback_timer3 */
}

/* Callback_timer4 function */
void Callback_timer4(void const * argument)
{
  /* USER CODE BEGIN Callback_timer4 */
	xSemaphoreGiveFromISR(timer4SemaphoreHandle,0);
  /* USER CODE END Callback_timer4 */
}

/* Callback_timer5 function */
void Callback_timer5(void const * argument)
{
  /* USER CODE BEGIN Callback_timer5 */
	xSemaphoreGiveFromISR(timer5SemaphoreHandle,0);
  /* USER CODE END Callback_timer5 */
}

/* Callback_pwm function */
void Callback_pwm(void const * argument)
{
  /* USER CODE BEGIN Callback_pwm */
	xSemaphoreGiveFromISR(pwm_SemaphoreHandle,0);
  /* USER CODE END Callback_pwm */
}

/* Callback_sekunda function */
void Callback_sekunda(void const * argument)
{
  /* USER CODE BEGIN Callback_sekunda */
	xSemaphoreGiveFromISR(timer_sekunda_SemaphoreHandle,0);
  /* USER CODE END Callback_sekunda */
}

/* Callback_timer6 function */
void Callback_timer6(void const * argument)
{
  /* USER CODE BEGIN Callback_timer6 */
	xSemaphoreGiveFromISR(timer6_SemaphoreHandle,0);
  /* USER CODE END Callback_timer6 */
}

/* Callback_timer7 function */
void Callback_timer7(void const * argument)
{
  /* USER CODE BEGIN Callback_timer7 */
	xSemaphoreGiveFromISR(timer7_SemaphoreHandle,0);
  /* USER CODE END Callback_timer7 */
}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM1 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM1) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1)
	{
	}
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
	/* User can add his own implementation to report the file name and line number,
ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

